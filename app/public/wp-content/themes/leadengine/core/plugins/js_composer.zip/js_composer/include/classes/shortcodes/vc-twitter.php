<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/**
 * Class WPBakeryShortCode_Vc_Twitter
 */
class WPBakeryShortCode_Vc_Twitter extends WPBakeryShortCode {
}
